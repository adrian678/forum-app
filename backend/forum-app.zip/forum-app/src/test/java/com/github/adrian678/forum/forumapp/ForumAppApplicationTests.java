package com.github.adrian678.forum.forumapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
